$(document).ready(function(){
  $('#chat-container').load("/mafija2/resources/views/chat.html");
});
